const state = {
  conversationId: null,
  requestId: null,
  generating: false,
  conversations: [],
  abortController: null
};

const $ = id => document.getElementById(id);
const messagesEl = $("messages");
const input = $("input");
const sendBtn = $("sendBtn");
const stopBtn = $("stopBtn");
const modelEl = $("model");
const personaEl = $("persona");
const errorBox = $("errorBox");

function escapeHtml(s) {
  return s.replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

function clearError() {
  errorBox.textContent = "";
  errorBox.classList.add("hidden");
}

function showError(message) {
  errorBox.textContent = message;
  errorBox.classList.remove("hidden");
}

function setGenerating(value) {
  state.generating = value;
  sendBtn.classList.toggle("hidden", value);
  stopBtn.classList.toggle("hidden", !value);
  input.disabled = value;
  modelEl.disabled = value;
  personaEl.disabled = value;
}

function scrollBottom() {
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function resetMessages() {
  messagesEl.innerHTML = '<div id="emptyState" class="empty"><h1>How can I help?</h1><p>Ask a question, write code, analyze an idea, or start a conversation.</p></div>';
}

function addMessage(role, text = "") {
  $("emptyState")?.remove();
  const el = document.createElement("div");
  el.className = `message ${role}`;
  el.innerHTML = `
    <div class="avatar">${role === "user" ? "YOU" : "AI"}</div>
    <div class="body">
      <div class="role">${role === "user" ? "YOU" : "AI"}</div>
      <div class="content"></div>
    </div>`;
  el.querySelector(".content").textContent = text;
  messagesEl.appendChild(el);
  scrollBottom();
  return el.querySelector(".content");
}

async function loadModels() {
  const r = await fetch("/api/models");
  const data = await r.json();
  modelEl.innerHTML = "";
  for (const m of data.models || []) {
    const o = document.createElement("option");
    o.value = m.name;
    o.textContent = m.name;
    modelEl.appendChild(o);
  }
  if (!modelEl.options.length) {
    for (const name of ["llama3.1:8b", "qwen2.5:7b"]) {
      const o = document.createElement("option");
      o.value = name; o.textContent = name; modelEl.appendChild(o);
    }
  }
}

async function loadPersonas() {
  const r = await fetch("/api/personas");
  const data = await r.json();
  personaEl.innerHTML = "";
  for (const p of data.personas || []) {
    const o = document.createElement("option");
    o.value = p.id; o.textContent = p.name; personaEl.appendChild(o);
  }
}

async function checkOllama() {
  try {
    const r = await fetch("/api/ollama/health");
    const d = await r.json();
    $("ollamaStatus").textContent = d.ok ? "● Ollama online" : "● Ollama offline";
    $("ollamaStatus").className = `status ${d.ok ? "ok" : "bad"}`;
  } catch {
    $("ollamaStatus").textContent = "● Ollama offline";
    $("ollamaStatus").className = "status bad";
  }
}

function renderConversationList() {
  const box = $("conversationList");
  box.innerHTML = "";
  for (const c of state.conversations) {
    const el = document.createElement("div");
    el.className = `conv ${c.id === state.conversationId ? "active" : ""}`;
    el.textContent = c.title || "New Chat";
    el.onclick = () => openConversation(c.id);
    box.appendChild(el);
  }
}

async function loadConversations() {
  const r = await fetch("/api/conversations");
  const d = await r.json();
  state.conversations = d.conversations || [];
  renderConversationList();
}

async function createNewChat() {
  if (state.generating) return;
  clearError();
  const r = await fetch("/api/conversations", {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({
      model: modelEl.value || "llama3.1:8b",
      persona: personaEl.value || "general"
    })
  });
  const d = await r.json();
  state.conversationId = d.conversation.id;
  $("chatTitle").textContent = "New Chat";
  resetMessages();
  await loadConversations();
  input.focus();
}

async function openConversation(id) {
  if (state.generating) return;
  clearError();
  const r = await fetch(`/api/conversations/${id}`);
  if (!r.ok) return showError("Unable to open conversation.");
  const c = await r.json();

  state.conversationId = c.id;
  $("chatTitle").textContent = c.title || "New Chat";
  if (c.model) modelEl.value = c.model;
  if (c.persona) personaEl.value = c.persona;

  resetMessages();
  for (const m of c.messages || []) {
    if (m.role === "user" || m.role === "assistant") addMessage(m.role, m.content);
  }
  renderConversationList();
  scrollBottom();
}

async function stopGeneration() {
  if (!state.requestId) return;
  try {
    await fetch("/api/chat/stop", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({request_id: state.requestId})
    });
  } catch {}
  if (state.abortController) state.abortController.abort();
  setGenerating(false);
  state.requestId = null;
  input.focus();
}

async function sendMessage() {
  if (state.generating) return;
  const text = input.value.trim();
  if (!text) return;

  clearError();
  const userText = text;
  input.value = "";
  autoResize();

  if (!state.conversationId) {
    await createNewChat();
  }

  addMessage("user", userText);
  const assistantContent = addMessage("assistant", "");

  state.requestId = crypto.randomUUID();
  setGenerating(true);

  const controller = new AbortController();
  state.abortController = controller;

  try {
    const r = await fetch("/api/chat", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({
        conversation_id: state.conversationId,
        message: userText,
        model: modelEl.value,
        persona: personaEl.value,
        request_id: state.requestId
      }),
      signal: controller.signal
    });

    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.error || `HTTP ${r.status}`);
    }

    const reader = r.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const {value, done} = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, {stream:true});

      const events = buffer.split("\n\n");
      buffer = events.pop();

      for (const raw of events) {
        const lines = raw.split("\n");
        const event = lines.find(x => x.startsWith("event:"))?.slice(6).trim();
        const dataLine = lines.find(x => x.startsWith("data:"))?.slice(5).trim();
        if (!dataLine) continue;

        const data = JSON.parse(dataLine);

        if (event === "token") {
          assistantContent.textContent += data.text || "";
          scrollBottom();
        } else if (event === "done") {
          state.conversationId = data.conversation_id;
          $("chatTitle").textContent = userText.slice(0, 60);
        } else if (event === "error") {
          showError(data.error || "Generation failed.");
        }
      }
    }

    await loadConversations();
  } catch (err) {
    if (err.name !== "AbortError") {
      showError(err.message || "Generation failed.");
    }
  } finally {
    state.abortController = null;
    state.requestId = null;
    setGenerating(false);
    input.focus();
  }
}

function autoResize() {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 180) + "px";
}

$("newChat").onclick = createNewChat;
sendBtn.onclick = sendMessage;
stopBtn.onclick = stopGeneration;

input.addEventListener("input", autoResize);
input.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

modelEl.addEventListener("change", async () => {
  if (state.conversationId && !state.generating) {
    await fetch(`/api/conversations/${state.conversationId}`, {
      method: "PATCH",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({model: modelEl.value})
    });
  }
});

personaEl.addEventListener("change", async () => {
  if (state.conversationId && !state.generating) {
    await fetch(`/api/conversations/${state.conversationId}`, {
      method: "PATCH",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({persona: personaEl.value})
    });
  }
});

(async function boot() {
  try {
    await loadModels();
    await loadPersonas();
    await checkOllama();
    await loadConversations();

    if (state.conversations.length) {
      await openConversation(state.conversations[0].id);
    } else {
      await createNewChat();
    }
  } catch (e) {
    showError(e.message || "Application initialization failed.");
  }
})();
