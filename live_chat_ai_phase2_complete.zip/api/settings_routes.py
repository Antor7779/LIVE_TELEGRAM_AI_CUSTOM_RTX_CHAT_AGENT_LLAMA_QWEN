from flask import Blueprint, jsonify
from ai.config_loader import load_settings, load_personas

settings_bp = Blueprint("settings", __name__)


@settings_bp.get("/settings")
def settings():
    s = load_settings()
    return jsonify({
        "default_model": s["default_model"],
        "default_persona": s["default_persona"],
        "temperature": s["temperature"],
        "num_ctx": s["num_ctx"]
    })


@settings_bp.get("/personas")
def personas():
    p = load_personas()
    return jsonify({
        "personas": [
            {"id": k, "name": v["name"]}
            for k, v in p.items()
        ]
    })
