from flask import Blueprint, jsonify
from ai.ollama_client import list_models, health

model_bp = Blueprint("model", __name__)


@model_bp.get("/models")
def models():
    try:
        return jsonify({"models": list_models()})
    except Exception as exc:
        return jsonify({"models": [], "error": str(exc)}), 503


@model_bp.get("/ollama/health")
def ollama_health():
    return jsonify(health())
