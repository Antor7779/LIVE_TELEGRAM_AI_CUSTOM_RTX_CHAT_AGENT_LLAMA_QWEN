from flask import Blueprint, jsonify, request
from database.repository import (
    create_conversation,
    get_conversation,
    list_conversations,
    get_messages,
    update_conversation,
    delete_conversation,
)

conversation_bp = Blueprint("conversation", __name__)


@conversation_bp.get("/conversations")
def conversations():
    return jsonify({"conversations": [dict(x) for x in list_conversations()]})


@conversation_bp.post("/conversations")
def new_conversation():
    data = request.get_json(silent=True) or {}
    cid = create_conversation(
        title=data.get("title") or "New Chat",
        model=data.get("model") or "llama3.1:8b",
        persona=data.get("persona") or "general",
    )
    return jsonify({"conversation": dict(get_conversation(cid))}), 201


@conversation_bp.get("/conversations/<int:cid>")
def conversation(cid):
    c = get_conversation(cid)
    if not c:
        return jsonify({"error": "Conversation not found"}), 404
    result = dict(c)
    result["messages"] = [dict(x) for x in get_messages(cid)]
    return jsonify(result)


@conversation_bp.patch("/conversations/<int:cid>")
def patch_conversation(cid):
    data = request.get_json(silent=True) or {}
    update_conversation(
        cid,
        title=data.get("title"),
        model=data.get("model"),
        persona=data.get("persona"),
    )
    c = get_conversation(cid)
    return jsonify({"conversation": dict(c)})


@conversation_bp.delete("/conversations/<int:cid>")
def remove_conversation(cid):
    delete_conversation(cid)
    return jsonify({"ok": True})
