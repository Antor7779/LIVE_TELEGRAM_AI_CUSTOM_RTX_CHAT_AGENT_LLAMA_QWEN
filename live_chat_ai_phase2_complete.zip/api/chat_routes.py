from __future__ import annotations

import json
import uuid
from flask import Blueprint, Response, jsonify, request, stream_with_context

from ai.config_loader import load_settings
from ai.context_engine import build_messages
from ai.ollama_client import stream_chat
from ai.conversation_engine import ensure_conversation, maybe_title
from ai.streaming_engine import registry
from database.repository import add_message, get_conversation

chat_bp = Blueprint("chat", __name__)
settings = load_settings()


def sse(event, payload):
    return f"event: {event}\ndata: {json.dumps(payload, ensure_ascii=False)}\n\n"


@chat_bp.post("/chat")
def chat():
    data = request.get_json(silent=True) or {}

    text = str(data.get("message", "")).strip()
    if not text:
        return jsonify({"error": "Message is empty"}), 400

    model = str(data.get("model") or settings["default_model"])
    persona = str(data.get("persona") or settings["default_persona"])
    request_id = str(data.get("request_id") or uuid.uuid4())

    try:
        conversation_id = int(data["conversation_id"]) if data.get("conversation_id") else None
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid conversation_id"}), 400

    if conversation_id:
        conversation = get_conversation(conversation_id)
        if not conversation:
            return jsonify({"error": "Conversation not found"}), 404
    else:
        conversation_id = ensure_conversation(None, model, persona)

    # Persist the user's message exactly once.
    add_message(conversation_id, "user", text, model)

    messages = build_messages(
        conversation_id,
        persona,
        model,
        # The current user message is already persisted, and build_messages
        # also appends it. To avoid duplication, construct from history minus
        # the final persisted user entry.
        text,
    )

    state = registry.create(request_id)

    @stream_with_context
    def generate():
        accumulated = ""
        try:
            yield sse("start", {
                "request_id": request_id,
                "conversation_id": conversation_id,
                "model": model
            })

            for chunk in stream_chat(
                messages,
                model=model,
                temperature=float(data.get("temperature", settings["temperature"])),
                num_ctx=int(data.get("num_ctx", settings["num_ctx"])),
            ):
                if state.stopped.is_set():
                    yield sse("stopped", {
                        "request_id": request_id,
                        "conversation_id": conversation_id,
                        "text": accumulated
                    })
                    return

                piece = (chunk.get("message") or {}).get("content", "")
                if piece:
                    accumulated += piece
                    state.text = accumulated
                    yield sse("token", {
                        "request_id": request_id,
                        "conversation_id": conversation_id,
                        "text": piece
                    })

                if chunk.get("done"):
                    break

            if accumulated:
                add_message(conversation_id, "assistant", accumulated, model)
                maybe_title(conversation_id, text)

            state.finished = True

            yield sse("done", {
                "request_id": request_id,
                "conversation_id": conversation_id,
                "text": accumulated
            })

        except Exception as exc:
            state.error = str(exc)
            yield sse("error", {
                "request_id": request_id,
                "conversation_id": conversation_id,
                "error": str(exc),
                "partial": accumulated
            })
        finally:
            registry.remove(request_id)

    return Response(
        generate(),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
        },
    )


@chat_bp.post("/chat/stop")
def stop_chat():
    data = request.get_json(silent=True) or {}
    request_id = str(data.get("request_id", "")).strip()

    if not request_id:
        return jsonify({"error": "request_id is required"}), 400

    return jsonify({
        "ok": registry.stop(request_id),
        "request_id": request_id
    })
