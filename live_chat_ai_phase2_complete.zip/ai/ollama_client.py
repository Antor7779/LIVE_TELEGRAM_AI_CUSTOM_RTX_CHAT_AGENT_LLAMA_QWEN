from __future__ import annotations

import json
from typing import Iterator, Any
import requests

from .config_loader import load_settings

settings = load_settings()
OLLAMA_URL = settings["ollama_url"].rstrip("/")


class OllamaError(RuntimeError):
    pass


def list_models() -> list[dict[str, Any]]:
    r = requests.get(f"{OLLAMA_URL}/api/tags", timeout=10)
    r.raise_for_status()
    return r.json().get("models", [])


def health() -> dict[str, Any]:
    try:
        r = requests.get(f"{OLLAMA_URL}/api/tags", timeout=3)
        return {"ok": r.ok, "status": r.status_code}
    except requests.RequestException as exc:
        return {"ok": False, "error": str(exc)}


def stream_chat(messages, model, temperature=0.7, num_ctx=8192) -> Iterator[dict]:
    payload = {
        "model": model,
        "messages": messages,
        "stream": True,
        "options": {
            "temperature": float(temperature),
            "num_ctx": int(num_ctx)
        }
    }

    try:
        with requests.post(
            f"{OLLAMA_URL}/api/chat",
            json=payload,
            stream=True,
            timeout=(10, 1800),
        ) as r:
            if not r.ok:
                try:
                    detail = r.json()
                except Exception:
                    detail = r.text
                raise OllamaError(f"Ollama HTTP {r.status_code}: {detail}")

            for raw in r.iter_lines(decode_unicode=True):
                if not raw:
                    continue
                try:
                    yield json.loads(raw)
                except json.JSONDecodeError:
                    continue
    except requests.RequestException as exc:
        raise OllamaError(str(exc)) from exc
