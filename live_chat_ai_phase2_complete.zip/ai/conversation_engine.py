from database.repository import (
    create_conversation,
    get_conversation,
    update_conversation,
    add_message,
)


def ensure_conversation(conversation_id, model, persona):
    if conversation_id:
        existing = get_conversation(conversation_id)
        if existing:
            return existing["id"]

    return create_conversation(
        title="New Chat",
        model=model,
        persona=persona,
    )


def set_message_pair(conversation_id, user_text, assistant_text, model):
    add_message(conversation_id, "user", user_text, model)
    add_message(conversation_id, "assistant", assistant_text, model)


def maybe_title(conversation_id, text):
    clean = " ".join(text.strip().split())
    if not clean:
        return
    title = clean[:60] + ("…" if len(clean) > 60 else "")
    update_conversation(conversation_id, title=title)
