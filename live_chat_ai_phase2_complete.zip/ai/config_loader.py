from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent.parent
CONFIG_DIR = ROOT / "config"


def load_settings():
    with open(CONFIG_DIR / "settings.json", "r", encoding="utf-8") as f:
        return json.load(f)


def load_personas():
    with open(CONFIG_DIR / "personas.json", "r", encoding="utf-8") as f:
        return json.load(f)
