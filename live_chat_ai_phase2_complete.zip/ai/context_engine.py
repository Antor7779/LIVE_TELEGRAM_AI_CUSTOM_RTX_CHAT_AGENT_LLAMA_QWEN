from .config_loader import load_personas, load_settings
from database.repository import get_messages

settings = load_settings()
personas = load_personas()


def build_messages(conversation_id: int, persona: str, model: str, user_text: str):
    persona_data = personas.get(persona, personas["general"])
    history = get_messages(conversation_id)

    max_history = int(settings.get("max_history_messages", 40))
    history = history[-max_history:]

    messages = [
        {"role": "system", "content": persona_data["system"]}
    ]

    for item in history:
        role = item["role"]
        content = item["content"]
        if role in ("system", "user", "assistant") and content:
            messages.append({"role": role, "content": content})

    messages.append({"role": "user", "content": user_text})
    return messages
