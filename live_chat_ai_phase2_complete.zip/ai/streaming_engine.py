from __future__ import annotations

from dataclasses import dataclass
from threading import Event


@dataclass
class GenerationState:
    request_id: str
    stopped: Event
    finished: bool = False
    error: str | None = None
    text: str = ""


class GenerationRegistry:
    def __init__(self):
        self._items: dict[str, GenerationState] = {}

    def create(self, request_id):
        state = GenerationState(request_id=request_id, stopped=Event())
        self._items[request_id] = state
        return state

    def get(self, request_id):
        return self._items.get(request_id)

    def stop(self, request_id):
        state = self._items.get(request_id)
        if state:
            state.stopped.set()
            return True
        return False

    def remove(self, request_id):
        self._items.pop(request_id, None)


registry = GenerationRegistry()
