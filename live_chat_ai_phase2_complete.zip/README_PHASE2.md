# Local AI Chat — Phase 2

Phase 2 is a complete replacement of the Phase 1 runtime/UI layer.

## Features

- Local Ollama inference
- Llama 3.1 8B / Qwen 2.5 7B
- True HTTP streaming from Ollama
- Stable Send state
- Stop generation
- New conversation
- Conversation switching
- SQLite persistence
- Model selection
- Persona selection
- Retry-ready error handling
- Enter to send / Shift+Enter newline
- No page refresh required

## Existing database

The application preserves the existing `data/chat.db` schema and performs a basic legacy migration if `messages.conversation_id` is missing.

## Run

```powershell
cd E:\AI_Script_writer\live_chat_ai
.\.venv\Scripts\Activate.ps1
python .\app.py
```

Open:

http://127.0.0.1:7860

## Important

Ollama must be running locally:

http://127.0.0.1:11434

Check:

```powershell
ollama list
```
