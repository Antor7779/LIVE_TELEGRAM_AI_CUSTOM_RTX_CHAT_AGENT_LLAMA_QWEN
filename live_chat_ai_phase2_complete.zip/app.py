from flask import Flask, send_from_directory
from pathlib import Path

from database.database import init_db
from api.chat_routes import chat_bp
from api.conversation_routes import conversation_bp
from api.model_routes import model_bp
from api.settings_routes import settings_bp

ROOT = Path(__file__).resolve().parent
UI_DIR = ROOT / "ui"

app = Flask(__name__, static_folder=None)
app.config["JSON_SORT_KEYS"] = False

init_db()

app.register_blueprint(chat_bp, url_prefix="/api")
app.register_blueprint(conversation_bp, url_prefix="/api")
app.register_blueprint(model_bp, url_prefix="/api")
app.register_blueprint(settings_bp, url_prefix="/api")


@app.get("/")
def index():
    return send_from_directory(UI_DIR, "index.html")


@app.get("/ui/<path:filename>")
def ui_files(filename):
    return send_from_directory(UI_DIR, filename)


@app.get("/health")
def health():
    return {"ok": True, "service": "live_chat_ai_phase2"}


if __name__ == "__main__":
    print("=" * 72)
    print("LOCAL AI CHAT — PHASE 2")
    print("=" * 72)
    print("Web:     http://127.0.0.1:7860")
    print("Ollama:  http://127.0.0.1:11434")
    print("Features: streaming, conversations, retry, stop, model/persona state")
    print("=" * 72)
    app.run(host="127.0.0.1", port=7860, debug=False, threaded=True)
