from __future__ import annotations
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
DB_PATH = DATA_DIR / "chat.db"


def get_connection():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn


def _columns(conn, table):
    return {r["name"] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}


def init_db():
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL DEFAULT 'New Chat',
                model TEXT NOT NULL DEFAULT 'llama3.1:8b',
                persona TEXT NOT NULL DEFAULT 'general',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)

        cols = _columns(conn, "conversations")
        for name, ddl in [
            ("title", "TEXT NOT NULL DEFAULT 'New Chat'"),
            ("model", "TEXT NOT NULL DEFAULT 'llama3.1:8b'"),
            ("persona", "TEXT NOT NULL DEFAULT 'general'"),
            ("created_at", "TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP"),
            ("updated_at", "TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP"),
        ]:
            if name not in cols:
                conn.execute(f"ALTER TABLE conversations ADD COLUMN {name} {ddl}")

        if conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='messages'").fetchone():
            msgcols = _columns(conn, "messages")
            if "conversation_id" not in msgcols:
                conn.execute("ALTER TABLE messages RENAME TO messages_legacy")
                conn.execute("""
                    CREATE TABLE messages (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        conversation_id INTEGER NOT NULL,
                        role TEXT NOT NULL CHECK(role IN ('system','user','assistant')),
                        content TEXT NOT NULL,
                        model TEXT,
                        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
                    )
                """)
                conn.execute("""
                    INSERT INTO conversations(title, model, persona)
                    VALUES('Migrated Chat','llama3.1:8b','general')
                """)
                cid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
                legacy = msgcols
                content = "content" if "content" in legacy else ("message" if "message" in legacy else "text")
                role = "role" if "role" in legacy else "'user'"
                created = "created_at" if "created_at" in legacy else "CURRENT_TIMESTAMP"
                conn.execute(f"""
                    INSERT INTO messages(conversation_id,role,content,created_at)
                    SELECT ?, {role}, COALESCE({content},''), COALESCE({created},CURRENT_TIMESTAMP)
                    FROM messages_legacy
                """, (cid,))
                conn.execute("DROP TABLE messages_legacy")
        else:
            conn.execute("""
                CREATE TABLE messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    conversation_id INTEGER NOT NULL,
                    role TEXT NOT NULL CHECK(role IN ('system','user','assistant')),
                    content TEXT NOT NULL,
                    model TEXT,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
                )
            """)

        conn.execute("CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id,id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_conversations_updated ON conversations(updated_at DESC)")
        conn.commit()
