from .database import get_connection


def create_conversation(title="New Chat", model="llama3.1:8b", persona="general"):
    with get_connection() as conn:
        cur = conn.execute(
            "INSERT INTO conversations(title,model,persona) VALUES(?,?,?)",
            (title, model, persona),
        )
        conn.commit()
        return cur.lastrowid


def get_conversation(conversation_id):
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM conversations WHERE id=?",
            (conversation_id,),
        ).fetchone()


def list_conversations():
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM conversations ORDER BY updated_at DESC,id DESC"
        ).fetchall()


def update_conversation(conversation_id, title=None, model=None, persona=None):
    fields, values = [], []
    if title is not None:
        fields.append("title=?"); values.append(title)
    if model is not None:
        fields.append("model=?"); values.append(model)
    if persona is not None:
        fields.append("persona=?"); values.append(persona)
    fields.append("updated_at=CURRENT_TIMESTAMP")
    values.append(conversation_id)
    with get_connection() as conn:
        conn.execute(
            f"UPDATE conversations SET {','.join(fields)} WHERE id=?",
            values,
        )
        conn.commit()


def delete_conversation(conversation_id):
    with get_connection() as conn:
        conn.execute("DELETE FROM conversations WHERE id=?", (conversation_id,))
        conn.commit()


def add_message(conversation_id, role, content, model=None):
    with get_connection() as conn:
        cur = conn.execute(
            "INSERT INTO messages(conversation_id,role,content,model) VALUES(?,?,?,?)",
            (conversation_id, role, content, model),
        )
        conn.execute(
            "UPDATE conversations SET updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (conversation_id,),
        )
        conn.commit()
        return cur.lastrowid


def get_messages(conversation_id):
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM messages WHERE conversation_id=? ORDER BY id",
            (conversation_id,),
        ).fetchall()
