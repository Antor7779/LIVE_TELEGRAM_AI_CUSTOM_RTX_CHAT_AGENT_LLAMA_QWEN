const state = {
  conversationId: null,
  requestId: null,
  generating: false,
  conversations: [],
  abortController: null,
  generationToken: 0
};

const $ = id => document.getElementById(id);
const messagesEl = $("messages");
const input = $("input");
const sendBtn = $("sendBtn");
const stopBtn = $("stopBtn");
const modelEl = $("model");
const personaEl = $("persona");
const errorBox = $("errorBox");

function clearError() {
  errorBox.textContent = "";
  errorBox.classList.add("hidden");
}

function showError(message) {
  errorBox.textContent = message;
  errorBox.classList.remove("hidden");
}

function scrollBottom() {
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function resetMessages() {
  messagesEl.innerHTML =
    '<div id="emptyState" class="empty">' +
    '<h1>How can I help?</h1>' +
    '<p>Ask a question, write code, analyze an idea, or start a conversation.</p>' +
    '</div>';
}

function addMessage(role, text = "") {
  const empty = $("emptyState");
  if (empty) empty.remove();

  const el = document.createElement("div");
  el.className = `message ${role}`;
  el.innerHTML = `
    <div class="avatar">${role === "user" ? "YOU" : "AI"}</div>
    <div class="body">
      <div class="role">${role === "user" ? "YOU" : "AI"}</div>
      <div class="content"></div>
    </div>`;

  el.querySelector(".content").textContent = text;
  messagesEl.appendChild(el);
  scrollBottom();

  return el.querySelector(".content");
}

/*
 * IMPORTANT:
 * We deliberately do NOT disable New Chat while generation is active.
 * A user must always be able to abandon the current generation and start
 * another conversation.
 */
function setGenerating(value) {
  state.generating = Boolean(value);

  sendBtn.classList.toggle("hidden", state.generating);
  stopBtn.classList.toggle("hidden", !state.generating);

  input.disabled = state.generating;
  modelEl.disabled = state.generating;

  // Persona/model can be changed after stopping.
  // New Chat is never disabled.
  $("newChat").disabled = false;

  if (state.generating) {
    input.placeholder = "AI is generating…";
  } else {
    input.placeholder = "Message your local AI…";
  }
}

async function loadModels() {
  const r = await fetch("/api/models", { cache: "no-store" });
  const data = await r.json();

  modelEl.innerHTML = "";

  for (const m of data.models || []) {
    const o = document.createElement("option");
    o.value = m.name;
    o.textContent = m.name;
    modelEl.appendChild(o);
  }

  if (!modelEl.options.length) {
    for (const name of ["llama3.1:8b", "qwen2.5:7b"]) {
      const o = document.createElement("option");
      o.value = name;
      o.textContent = name;
      modelEl.appendChild(o);
    }
  }
}

async function loadPersonas() {
  const r = await fetch("/api/personas", { cache: "no-store" });
  const data = await r.json();

  personaEl.innerHTML = "";

  for (const p of data.personas || []) {
    const o = document.createElement("option");
    o.value = p.id;
    o.textContent = p.name;
    personaEl.appendChild(o);
  }
}

async function checkOllama() {
  try {
    const r = await fetch("/api/ollama/health", { cache: "no-store" });
    const d = await r.json();

    $("ollamaStatus").textContent =
      d.ok ? "● Ollama online" : "● Ollama offline";

    $("ollamaStatus").className =
      `status ${d.ok ? "ok" : "bad"}`;
  } catch {
    $("ollamaStatus").textContent = "● Ollama offline";
    $("ollamaStatus").className = "status bad";
  }
}

function renderConversationList() {
  const box = $("conversationList");
  box.innerHTML = "";

  for (const c of state.conversations) {
    const el = document.createElement("div");

    el.className =
      `conv ${Number(c.id) === Number(state.conversationId) ? "active" : ""}`;

    el.textContent = c.title || "New Chat";

    el.onclick = async () => {
      await openConversation(c.id);
    };

    box.appendChild(el);
  }
}

async function loadConversations() {
  const r = await fetch("/api/conversations", { cache: "no-store" });
  if (!r.ok) throw new Error("Unable to load conversations.");

  const d = await r.json();
  state.conversations = d.conversations || [];
  renderConversationList();
}

/*
 * Stop the current generation completely from the UI's point of view.
 * We wait for the abort request before allowing another generation.
 */
async function stopGeneration() {
  const requestId = state.requestId;

  if (!requestId) {
    setGenerating(false);
    return;
  }

  try {
    await fetch("/api/chat/stop", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({request_id: requestId}),
      cache: "no-store"
    });
  } catch (e) {
    console.warn("Stop request failed:", e);
  }

  if (state.abortController) {
    try {
      state.abortController.abort();
    } catch {}
  }

  state.generationToken++;
  state.requestId = null;
  state.abortController = null;

  setGenerating(false);

  // Re-render the conversation list so the active conversation remains usable.
  try {
    await loadConversations();
  } catch {}

  input.focus();
}

/*
 * NEW CHAT is intentionally allowed while AI is generating.
 * If generation is active, stop it first, then create the new conversation.
 */
async function createNewChat() {
  clearError();

  if (state.generating) {
    await stopGeneration();
  }

  const r = await fetch("/api/conversations", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({
      model: modelEl.value || "llama3.1:8b",
      persona: personaEl.value || "general"
    }),
    cache: "no-store"
  });

  if (!r.ok) {
    const d = await r.json().catch(() => ({}));
    throw new Error(d.error || "Unable to create a new chat.");
  }

  const d = await r.json();

  state.conversationId = d.conversation.id;
  $("chatTitle").textContent = "New Chat";

  resetMessages();

  await loadConversations();

  input.disabled = false;
  input.focus();
}

async function openConversation(id) {
  clearError();

  /*
   * Previously this function returned immediately when generating.
   * That made conversation switching appear completely broken.
   *
   * We now stop the active generation and then open the selected chat.
   */
  if (state.generating) {
    await stopGeneration();
  }

  const r = await fetch(`/api/conversations/${id}`, {
    cache: "no-store"
  });

  if (!r.ok) {
    showError("Unable to open conversation.");
    return;
  }

  const c = await r.json();

  state.conversationId = c.id;
  $("chatTitle").textContent = c.title || "New Chat";

  if (c.model) modelEl.value = c.model;
  if (c.persona) personaEl.value = c.persona;

  resetMessages();

  for (const m of c.messages || []) {
    if (m.role === "user" || m.role === "assistant") {
      addMessage(m.role, m.content);
    }
  }

  renderConversationList();
  scrollBottom();
  input.disabled = false;
  input.focus();
}

async function sendMessage() {
  if (state.generating) return;

  const text = input.value.trim();
  if (!text) return;

  clearError();

  if (!state.conversationId) {
    try {
      await createNewChat();
    } catch (e) {
      showError(e.message);
      return;
    }
  }

  const userText = text;
  input.value = "";
  autoResize();

  addMessage("user", userText);
  const assistantContent = addMessage("assistant", "");

  const requestId = crypto.randomUUID();

  state.requestId = requestId;
  state.generationToken++;
  const localToken = state.generationToken;

  setGenerating(true);

  const controller = new AbortController();
  state.abortController = controller;

  try {
    const r = await fetch("/api/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({
        conversation_id: state.conversationId,
        message: userText,
        model: modelEl.value,
        persona: personaEl.value,
        request_id: requestId
      }),
      signal: controller.signal,
      cache: "no-store"
    });

    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      throw new Error(d.error || `HTTP ${r.status}`);
    }

    if (!r.body) {
      throw new Error("Streaming response is not available.");
    }

    const reader = r.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const {value, done} = await reader.read();
      if (done) break;

      /*
       * Ignore stale data if another chat has already been opened.
       */
      if (localToken !== state.generationToken) {
        try { await reader.cancel(); } catch {}
        return;
      }

      buffer += decoder.decode(value, {stream: true});

      const events = buffer.split("\n\n");
      buffer = events.pop() || "";

      for (const raw of events) {
        const lines = raw.split("\n");

        const eventLine = lines.find(x => x.startsWith("event:"));
        const dataLine = lines.find(x => x.startsWith("data:"));

        if (!dataLine) continue;

        const event = eventLine
          ? eventLine.slice(6).trim()
          : "message";

        let data;

        try {
          data = JSON.parse(dataLine.slice(5).trim());
        } catch {
          continue;
        }

        if (event === "start") {
          state.conversationId = data.conversation_id;
          renderConversationList();
        }

        else if (event === "token") {
          assistantContent.textContent += data.text || "";
          scrollBottom();
        }

        else if (event === "stopped") {
          /*
           * Do not show this as an error.
           * The partial answer is intentionally retained.
           */
          if (data.text) {
            assistantContent.textContent = data.text;
          }
          return;
        }

        else if (event === "done") {
          state.conversationId = data.conversation_id;

          if (data.text && assistantContent.textContent !== data.text) {
            assistantContent.textContent = data.text;
          }

          $("chatTitle").textContent =
            userText.length > 60
              ? userText.slice(0, 60) + "…"
              : userText;

          await loadConversations();
        }

        else if (event === "error") {
          if (data.partial) {
            assistantContent.textContent = data.partial;
          }
          showError(data.error || "Generation failed.");
        }
      }
    }
  } catch (err) {
    /*
     * Abort is normal when Stop/New Chat/switching conversations is used.
     */
    if (err.name !== "AbortError") {
      showError(err.message || "Generation failed.");
    }
  } finally {
    /*
     * Only the generation that owns this request may change the global
     * generation state.
     */
    if (localToken === state.generationToken) {
      state.abortController = null;
      state.requestId = null;
      setGenerating(false);
      input.focus();
    }
  }
}

function autoResize() {
  input.style.height = "auto";
  input.style.height =
    Math.min(input.scrollHeight, 180) + "px";
}

/* NEVER disable this button. */
$("newChat").disabled = false;

$("newChat").onclick = async () => {
  try {
    await createNewChat();
  } catch (e) {
    showError(e.message || "Unable to create a new chat.");
  }
};

sendBtn.onclick = sendMessage;
stopBtn.onclick = stopGeneration;

input.addEventListener("input", autoResize);

input.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

modelEl.addEventListener("change", async () => {
  if (!state.conversationId || state.generating) return;

  await fetch(`/api/conversations/${state.conversationId}`, {
    method: "PATCH",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({model: modelEl.value})
  });
});

personaEl.addEventListener("change", async () => {
  if (!state.conversationId || state.generating) return;

  await fetch(`/api/conversations/${state.conversationId}`, {
    method: "PATCH",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({persona: personaEl.value})
  });
});

(async function boot() {
  try {
    await loadModels();
    await loadPersonas();
    await checkOllama();
    await loadConversations();

    if (state.conversations.length) {
      await openConversation(state.conversations[0].id);
    } else {
      await createNewChat();
    }
  } catch (e) {
    showError(e.message || "Application initialization failed.");
  }
})();
