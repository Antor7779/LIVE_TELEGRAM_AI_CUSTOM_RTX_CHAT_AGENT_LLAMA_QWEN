# Phase 2 Hotfix — Chat Navigation / Stop State

Replace:

    ui/js/app.js

with the supplied version.

Also replace:

    ai/context_engine.py

The frontend fix addresses the exact failure where:

- generation is active
- Send becomes Stop
- Stop is pressed
- New Chat / conversation switching remains unavailable

New behavior:

1. New Chat is NEVER disabled.
2. Clicking New Chat during generation automatically stops generation.
3. Conversation switching during generation automatically stops generation.
4. The current partial response is preserved.
5. Stale streaming tokens cannot overwrite the newly selected conversation.
6. Send becomes available again after Stop.
7. Model selection is re-enabled after Stop.
8. Input is re-enabled after Stop.
9. Current user message is no longer duplicated in Ollama context.

Hard refresh the browser after replacing the files:

Ctrl + Shift + R
