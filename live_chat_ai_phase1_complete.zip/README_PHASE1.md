# Local AI Chat — Phase 1

Professional local chat core using Flask + Ollama.

## Models
- llama3.1:8b
- qwen2.5:7b

## Start
```powershell
cd E:\AI_Script_writer\live_chat_ai
.\.venv\Scripts\Activate.ps1
python .\app.py
```

Open http://127.0.0.1:7860

## Architecture
- `ai/ollama_client.py` — Ollama streaming client
- `ai/context_engine.py` — persona + conversation context
- `database/` — SQLite persistence
- `api/` — REST/SSE endpoints
- `config/` — settings and personas
- `ui/` — professional web interface

The database is created automatically at `data/chat.db`.
