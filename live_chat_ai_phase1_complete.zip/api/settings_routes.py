from flask import Blueprint
from ai.config_loader import load_settings

settings_bp = Blueprint("settings", __name__)


@settings_bp.get("/settings")
def settings():
    data = load_settings()
    return {
        "default_model": data["default_model"],
        "default_persona": data["default_persona"],
        "temperature": data["temperature"],
        "history_limit": data["history_limit"]
    }
