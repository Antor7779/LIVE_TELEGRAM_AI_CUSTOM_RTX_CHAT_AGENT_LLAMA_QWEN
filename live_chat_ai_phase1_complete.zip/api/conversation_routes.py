from flask import Blueprint, request
from database import repository

conversation_bp = Blueprint("conversations", __name__)


@conversation_bp.get("/conversations")
def conversations():
    return {"conversations": repository.list_conversations()}


@conversation_bp.post("/conversations")
def create():
    data = request.get_json(silent=True) or {}
    model = data.get("model", "llama3.1:8b")
    persona = data.get("persona", "general")
    title = data.get("title", "New Chat")
    cid = repository.create_conversation(title, model, persona)
    return {"conversation": repository.get_conversation(cid)}, 201


@conversation_bp.get("/conversations/<int:conversation_id>")
def get(conversation_id):
    conv = repository.get_conversation(conversation_id)
    if not conv:
        return {"error": "Conversation not found."}, 404
    return {
        "conversation": conv,
        "messages": repository.list_messages(conversation_id)
    }


@conversation_bp.patch("/conversations/<int:conversation_id>")
def rename(conversation_id):
    data = request.get_json(silent=True) or {}
    title = str(data.get("title", "")).strip()
    if not title:
        return {"error": "Title is required."}, 400
    if not repository.get_conversation(conversation_id):
        return {"error": "Conversation not found."}, 404
    repository.rename_conversation(conversation_id, title)
    return {"conversation": repository.get_conversation(conversation_id)}


@conversation_bp.delete("/conversations/<int:conversation_id>")
def delete(conversation_id):
    if not repository.get_conversation(conversation_id):
        return {"error": "Conversation not found."}, 404
    repository.delete_conversation(conversation_id)
    return {"ok": True}
