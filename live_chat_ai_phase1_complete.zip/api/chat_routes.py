import json
from flask import Blueprint, Response, request, stream_with_context

from ai.config_loader import load_settings
from ai.context_engine import ContextEngine
from ai.ollama_client import OllamaClient, OllamaError
from database import repository

chat_bp = Blueprint("chat", __name__)
settings = load_settings()
ollama = OllamaClient(settings["ollama_url"], settings["stream_timeout"])
context = ContextEngine(settings["history_limit"])


@chat_bp.post("/chat")
def chat():
    data = request.get_json(silent=True) or {}
    conversation_id = data.get("conversation_id")
    message = str(data.get("message", "")).strip()
    model = str(data.get("model") or settings["default_model"])
    persona = str(data.get("persona") or settings["default_persona"])
    temperature = float(data.get("temperature", settings["temperature"]))

    if not message:
        return {"error": "Message is required."}, 400

    if conversation_id:
        conv = repository.get_conversation(int(conversation_id))
        if not conv:
            return {"error": "Conversation not found."}, 404
        conversation_id = int(conversation_id)
        model = model or conv["model"]
    else:
        title = message[:60] + ("..." if len(message) > 60 else "")
        conversation_id = repository.create_conversation(title, model, persona)

    history = repository.list_messages(conversation_id)
    messages = context.build_messages(persona, history, message)

    repository.add_message(conversation_id, "user", message, model)

    def generate():
        full = []
        try:
            meta = {
                "type": "start",
                "conversation_id": conversation_id,
                "model": model
            }
            yield f"data: {json.dumps(meta)}\n\n"

            for chunk in ollama.chat_stream(
                model=model,
                messages=messages,
                temperature=temperature
            ):
                full.append(chunk)
                yield f"data: {json.dumps({'type': 'token', 'content': chunk})}\n\n"

            answer = "".join(full)
            repository.add_message(conversation_id, "assistant", answer, model)
            yield f"data: {json.dumps({'type': 'done', 'conversation_id': conversation_id})}\n\n"

        except OllamaError as e:
            yield f"data: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive"
        }
    )
