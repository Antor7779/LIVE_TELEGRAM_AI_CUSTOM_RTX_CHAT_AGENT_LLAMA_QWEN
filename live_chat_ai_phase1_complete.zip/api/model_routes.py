from flask import Blueprint
from ai.config_loader import load_settings, load_personas
from ai.ollama_client import OllamaClient, OllamaError

model_bp = Blueprint("models", __name__)
settings = load_settings()
client = OllamaClient(settings["ollama_url"], settings["request_timeout"])


@model_bp.get("/models")
def models():
    try:
        items = client.models()
        return {
            "models": [
                {
                    "name": m.get("name"),
                    "size": m.get("size"),
                    "modified_at": m.get("modified_at")
                }
                for m in items
            ]
        }
    except OllamaError as e:
        return {"error": str(e)}, 503


@model_bp.get("/ollama/health")
def health():
    return {"online": client.health(), "url": settings["ollama_url"]}


@model_bp.get("/personas")
def personas():
    data = load_personas()
    return {
        "personas": [
            {"id": k, **v}
            for k, v in data.items()
        ]
    }
