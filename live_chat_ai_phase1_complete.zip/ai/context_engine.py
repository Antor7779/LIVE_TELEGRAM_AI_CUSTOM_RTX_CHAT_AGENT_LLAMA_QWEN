from config_loader import load_personas


class ContextEngine:
    def __init__(self, history_limit=30):
        self.history_limit = max(1, int(history_limit))
        self.personas = load_personas()

    def persona(self, persona_id):
        return self.personas.get(persona_id) or self.personas["general"]

    def build_messages(self, persona_id, history, user_message):
        p = self.persona(persona_id)
        messages = [{"role": "system", "content": p["system_prompt"]}]

        for item in history[-self.history_limit:]:
            role = item["role"]
            content = item["content"]
            if role in ("user", "assistant", "system") and content:
                messages.append({"role": role, "content": content})

        messages.append({"role": "user", "content": user_message})
        return messages
