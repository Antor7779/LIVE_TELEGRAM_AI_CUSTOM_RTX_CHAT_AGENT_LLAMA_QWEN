import json
import requests


class OllamaError(RuntimeError):
    pass


class OllamaClient:
    def __init__(self, base_url, timeout=300):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def health(self):
        try:
            r = requests.get(f"{self.base_url}/api/tags", timeout=10)
            r.raise_for_status()
            return True
        except requests.RequestException:
            return False

    def models(self):
        try:
            r = requests.get(f"{self.base_url}/api/tags", timeout=15)
            r.raise_for_status()
            return r.json().get("models", [])
        except requests.RequestException as e:
            raise OllamaError(f"Could not connect to Ollama: {e}") from e

    def chat_stream(self, model, messages, temperature=0.7):
        payload = {
            "model": model,
            "messages": messages,
            "stream": True,
            "options": {"temperature": temperature}
        }

        try:
            with requests.post(
                f"{self.base_url}/api/chat",
                json=payload,
                stream=True,
                timeout=(15, self.timeout)
            ) as r:
                if not r.ok:
                    try:
                        detail = r.json()
                    except Exception:
                        detail = r.text
                    raise OllamaError(f"Ollama HTTP {r.status_code}: {detail}")

                for line in r.iter_lines(decode_unicode=True):
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    if data.get("error"):
                        raise OllamaError(data["error"])

                    content = data.get("message", {}).get("content", "")
                    if content:
                        yield content

                    if data.get("done"):
                        break

        except requests.RequestException as e:
            raise OllamaError(f"Ollama request failed: {e}") from e
