import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG = ROOT / "config"

def load_settings():
    with open(CONFIG / "settings.json", "r", encoding="utf-8") as f:
        return json.load(f)

def load_personas():
    with open(CONFIG / "personas.json", "r", encoding="utf-8") as f:
        return json.load(f)
