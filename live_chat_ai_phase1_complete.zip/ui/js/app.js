const $ = id => document.getElementById(id);

let currentConversation = null;
let generating = false;

async function api(url, options={}) {
  const r = await fetch(url, options);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || `HTTP ${r.status}`);
  return data;
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

function addMessage(role, content="") {
  const box = $("messages");
  const welcome = box.querySelector(".welcome");
  if (welcome) welcome.remove();

  const el = document.createElement("div");
  el.className = `message ${role}`;
  el.innerHTML = `
    <div class="avatar">${role === "user" ? "YOU" : "AI"}</div>
    <div class="bubble"></div>
  `;
  el.querySelector(".bubble").textContent = content;
  box.appendChild(el);
  box.scrollTop = box.scrollHeight;
  return el.querySelector(".bubble");
}

async function loadModels() {
  try {
    const data = await api("/api/models");
    $("modelSelect").innerHTML = "";
    data.models.forEach(m => {
      const o = document.createElement("option");
      o.value = m.name;
      o.textContent = m.name;
      $("modelSelect").appendChild(o);
    });
    if (![...$("modelSelect").options].length) {
      $("modelSelect").innerHTML = '<option value="llama3.1:8b">llama3.1:8b</option>';
    }
  } catch (e) {
    $("modelSelect").innerHTML = '<option value="llama3.1:8b">llama3.1:8b</option>';
  }
}

async function loadPersonas() {
  const data = await api("/api/personas");
  $("personaSelect").innerHTML = "";
  data.personas.forEach(p => {
    const o = document.createElement("option");
    o.value = p.id;
    o.textContent = p.name;
    $("personaSelect").appendChild(o);
  });
}

async function checkHealth() {
  try {
    const data = await api("/api/ollama/health");
    $("statusDot").className = `status-dot ${data.online ? "online" : "offline"}`;
    $("statusText").textContent = data.online ? "Ollama online" : "Ollama offline";
  } catch {
    $("statusDot").className = "status-dot offline";
    $("statusText").textContent = "Ollama offline";
  }
}

async function loadConversations() {
  const data = await api("/api/conversations");
  const list = $("conversationList");
  list.innerHTML = "";
  data.conversations.forEach(c => {
    const el = document.createElement("div");
    el.className = "conversation" + (currentConversation === c.id ? " active" : "");
    el.textContent = c.title;
    el.title = c.title;
    el.onclick = () => openConversation(c.id);
    list.appendChild(el);
  });
}

async function openConversation(id) {
  const data = await api(`/api/conversations/${id}`);
  currentConversation = id;
  $("chatTitle").textContent = data.conversation.title;
  $("modelSelect").value = data.conversation.model;
  $("personaSelect").value = data.conversation.persona;

  $("messages").innerHTML = "";
  data.messages.filter(m => m.role !== "system").forEach(m => addMessage(m.role, m.content));
  await loadConversations();
}

async function newChat() {
  const data = await api("/api/conversations", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({
      model:$("modelSelect").value,
      persona:$("personaSelect").value,
      title:"New Chat"
    })
  });
  currentConversation = data.conversation.id;
  $("chatTitle").textContent = "New Chat";
  $("messages").innerHTML = `
    <div class="welcome">
      <div class="welcome-icon">✦</div>
      <h2>How can I help?</h2>
      <p>Your conversations run locally through Ollama.</p>
    </div>`;
  await loadConversations();
}

async function sendMessage() {
  if (generating) return;
  const input = $("messageInput");
  const message = input.value.trim();
  if (!message) return;

  generating = true;
  $("sendButton").disabled = true;
  input.value = "";
  input.style.height = "auto";

  addMessage("user", message);
  const bubble = addMessage("assistant", "");
  let answer = "";

  try {
    const response = await fetch("/api/chat", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        conversation_id: currentConversation,
        message,
        model:$("modelSelect").value,
        persona:$("personaSelect").value,
        temperature:0.7
      })
    });

    if (!response.ok) {
      throw new Error(await response.text());
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();

    while (true) {
      const {value, done} = await reader.read();
      if (done) break;

      const text = decoder.decode(value, {stream:true});
      for (const block of text.split("\n\n")) {
        if (!block.startsWith("data: ")) continue;
        try {
          const event = JSON.parse(block.slice(6));
          if (event.type === "start" && !currentConversation) {
            currentConversation = event.conversation_id;
          }
          if (event.type === "token") {
            answer += event.content;
            bubble.textContent = answer;
            $("messages").scrollTop = $("messages").scrollHeight;
          }
          if (event.type === "error") throw new Error(event.error);
        } catch (e) {
          if (e.message && e.message !== "Unexpected end of JSON input") throw e;
        }
      }
    }

    await loadConversations();
    if (currentConversation) {
      const c = await api(`/api/conversations/${currentConversation}`);
      $("chatTitle").textContent = c.conversation.title;
    }
  } catch (e) {
    bubble.textContent = `Error: ${e.message}`;
  } finally {
    generating = false;
    $("sendButton").disabled = false;
    input.focus();
  }
}

$("newChat").onclick = newChat;
$("sendButton").onclick = sendMessage;

$("messageInput").addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

$("messageInput").addEventListener("input", e => {
  e.target.style.height = "auto";
  e.target.style.height = Math.min(e.target.scrollHeight, 180) + "px";
});

(async function init() {
  try {
    await loadModels();
    await loadPersonas();
    await checkHealth();
    await loadConversations();
  } catch (e) {
    console.error(e);
  }
})();
