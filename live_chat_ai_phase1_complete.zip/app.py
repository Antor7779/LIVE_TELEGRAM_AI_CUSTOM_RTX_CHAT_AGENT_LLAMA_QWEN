from flask import Flask, send_from_directory
from api.chat_routes import chat_bp
from api.conversation_routes import conversation_bp
from api.model_routes import model_bp
from api.settings_routes import settings_bp
from database.database import init_db

BASE_DIR = __import__("pathlib").Path(__file__).resolve().parent

app = Flask(__name__, static_folder="ui", static_url_path="/ui")
app.config["JSON_SORT_KEYS"] = False

init_db()
app.register_blueprint(chat_bp, url_prefix="/api")
app.register_blueprint(conversation_bp, url_prefix="/api")
app.register_blueprint(model_bp, url_prefix="/api")
app.register_blueprint(settings_bp, url_prefix="/api")

@app.get("/")
def index():
    return send_from_directory(str(BASE_DIR / "ui"), "index.html")

@app.get("/health")
def health():
    return {"status": "ok", "service": "local-ai-chat"}

if __name__ == "__main__":
    print("=" * 72)
    print("LOCAL AI CHAT — PHASE 1")
    print("=" * 72)
    print("Web:     http://127.0.0.1:7860")
    print("Ollama:  http://127.0.0.1:11434")
    print("Models:  Llama 3.1 8B / Qwen 2.5 7B")
    print("=" * 72)
    app.run(host="127.0.0.1", port=7860, debug=False, threaded=True)
