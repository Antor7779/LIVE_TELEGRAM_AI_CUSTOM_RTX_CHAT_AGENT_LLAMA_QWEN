from database.database import get_connection


def create_conversation(title, model, persona):
    with get_connection() as conn:
        cur = conn.execute(
            "INSERT INTO conversations(title, model, persona) VALUES(?,?,?)",
            (title or "New Chat", model, persona)
        )
        return cur.lastrowid


def list_conversations():
    with get_connection() as conn:
        rows = conn.execute("""
            SELECT id, title, model, persona, created_at, updated_at
            FROM conversations
            ORDER BY datetime(updated_at) DESC, id DESC
        """).fetchall()
        return [dict(r) for r in rows]


def get_conversation(conversation_id):
    with get_connection() as conn:
        row = conn.execute(
            "SELECT * FROM conversations WHERE id=?", (conversation_id,)
        ).fetchone()
        return dict(row) if row else None


def rename_conversation(conversation_id, title):
    with get_connection() as conn:
        conn.execute(
            "UPDATE conversations SET title=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (title.strip() or "New Chat", conversation_id)
        )


def delete_conversation(conversation_id):
    with get_connection() as conn:
        conn.execute("DELETE FROM conversations WHERE id=?", (conversation_id,))


def add_message(conversation_id, role, content, model=None):
    with get_connection() as conn:
        cur = conn.execute(
            """INSERT INTO messages(conversation_id, role, content, model)
               VALUES(?,?,?,?)""",
            (conversation_id, role, content, model)
        )
        conn.execute(
            "UPDATE conversations SET updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (conversation_id,)
        )
        return cur.lastrowid


def list_messages(conversation_id):
    with get_connection() as conn:
        rows = conn.execute("""
            SELECT id, conversation_id, role, content, model, created_at
            FROM messages
            WHERE conversation_id=?
            ORDER BY id ASC
        """, (conversation_id,)).fetchall()
        return [dict(r) for r in rows]
